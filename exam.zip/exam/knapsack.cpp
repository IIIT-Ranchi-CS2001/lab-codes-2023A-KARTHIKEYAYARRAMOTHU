#include <bits/stdc++.h>
using namespace std;

int knapsack(int itemCount, int capacity, const vector<int>& values, const vector<int>& weights, vector<vector<int>>& dp) {
    if (itemCount == 0 || capacity == 0) return 0;

    if (dp[itemCount][capacity] != -1) return dp[itemCount][capacity];

    if (weights[itemCount - 1] > capacity) {
        return dp[itemCount][capacity] = knapsack(itemCount - 1, capacity, values, weights, dp);
    }

    return dp[itemCount][capacity] = max(
        knapsack(itemCount - 1, capacity, values, weights, dp),
        values[itemCount - 1] + knapsack(itemCount - 1, capacity - weights[itemCount - 1], values, weights, dp)
    );
}

int main() {
    int itemCount, capacity;
    cin >> itemCount >> capacity;
    vector<int> values(itemCount), weights(itemCount);
    for (int i = 0; i < itemCount; i++) cin >> values[i];
    for (int i = 0; i < itemCount; i++) cin >> weights[i];

    vector<vector<int>> dp(itemCount + 1, vector<int>(capacity + 1, -1));

    cout << knapsack(itemCount, capacity, values, weights, dp) << endl;

    return 0;
}
