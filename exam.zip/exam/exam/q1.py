import pandas as pd
import numpy as np

# Load the CSV file (adjust file path as necessary)
data = pd.read_csv(r'C:\Users\karth\Downloads\AQI_Data.csv')

# Display the first 5 and last 6 rows of the dataset
print(data.head())
print(data.tail(6))
    
# Show statistical summary of the dataset
print(data.describe())

# Calculate mean values for specific columns
if 'AQI' in data.columns:
    maqi = np.mean(data['AQI'])
    print(f"Mean AQI: {maqi}")

if 'PM2.5' in data.columns:
    mean_pm25 = np.mean(data['PM2.5'])
    print(f"Mean PM2.5: {mean_pm25}")

if 'PM10' in data.columns:
    mean_pm10 = np.mean(data['PM10'])
    print(f"Mean PM10: {mean_pm10}")
#finding the city with the highest average AQI value
highest_avg_aqi_city = data.groupby('City')['AQI'].mean().idxmax()
highest_avg_aqi_value = data.groupby('City')['AQI'].mean().max()

# Finding the city with the lowest average AQI value
lowest_avg_aqi_city = data.groupby('City')['AQI'].mean().idxmin()
lowest_avg_aqi_value = data.groupby('City')['AQI'].mean().min()

print(f"City with the highest average AQI: {highest_avg_aqi_city} with AQI value of {highest_avg_aqi_value}")
print(f"City with the lowest average AQI: {lowest_avg_aqi_city} with AQI value of {lowest_avg_aqi_value}")


