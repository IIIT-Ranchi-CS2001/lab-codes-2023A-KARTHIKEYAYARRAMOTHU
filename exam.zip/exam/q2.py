highest_avg_aqi_city = data.groupby('City')['AQI'].mean().idxmax()
highest_avg_aqi_value = data.groupby('City')['AQI'].mean().max()

# Finding the city with the lowest average AQI value
lowest_avg_aqi_city = data.groupby('City')['AQI'].mean().idxmin()
lowest_avg_aqi_value = data.groupby('City')['AQI'].mean().min()

print(f"City with the highest average AQI: {highest_avg_aqi_city} with AQI value of {highest_avg_aqi_value}")
print(f"City with the lowest average AQI: {lowest_avg_aqi_city} with AQI value of {lowest_avg_aqi_value}")